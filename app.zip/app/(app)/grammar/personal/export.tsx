import * as Clipboard from "expo-clipboard";
import { router } from "expo-router";
import { ArrowLeft, Check, Copy } from "lucide-react-native";
import { useMemo, useState } from "react";
import { Pressable, ScrollView, View } from "react-native";

import { Button, Card, Screen, Text, useToast } from "@/components/ui";
import {
  exportToJson,
  useHydratedPersonalDeck,
} from "@/features/grammar/personal";
import { useTheme } from "@/theme";

export default function ExportPersonal() {
  const theme = useTheme();
  const toast = useToast();
  const { hydrated, constructions } = useHydratedPersonalDeck();
  const [copied, setCopied] = useState(false);

  const json = useMemo(
    () => (hydrated ? exportToJson(constructions) : ""),
    [hydrated, constructions],
  );
  const totalPhrases = constructions.reduce((s, c) => s + c.patterns.length, 0);

  async function handleCopy() {
    if (!json) return;
    try {
      await Clipboard.setStringAsync(json);
      setCopied(true);
      toast.success("Скопировано в буфер обмена");
      setTimeout(() => setCopied(false), 2500);
    } catch {
      toast.error("Не удалось скопировать");
    }
  }

  return (
    <Screen padded>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: theme.spacing.md,
          paddingTop: theme.spacing.sm,
          paddingBottom: theme.spacing.md,
        }}
      >
        <Pressable onPress={() => router.back()} hitSlop={16} accessibilityLabel="Назад">
          <ArrowLeft color={theme.colors.textSecondary} size={24} strokeWidth={2} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text variant="caption" color="tertiary">
            ЛИЧНАЯ КОЛОДА
          </Text>
          <Text variant="h3">Экспорт JSON</Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingBottom: theme.spacing["3xl"],
          gap: theme.spacing.lg,
        }}
      >
        {!hydrated ? null : constructions.length === 0 ? (
          <Card padding="lg" bordered>
            <Text variant="bodyStrong">Нечего экспортировать</Text>
            <Text variant="small" color="secondary">
              Создайте хотя бы одну конструкцию, чтобы получить экспорт. Тот же
              JSON можно потом вставить через «Импорт JSON» на другом
              устройстве — связка работает в обе стороны.
            </Text>
          </Card>
        ) : (
          <>
            <Text variant="small" color="secondary">
              Свёрнутый JSON со всеми вашими конструкциями. Можно скопировать
              кнопкой ниже или выделить вручную (long-press по тексту). Формат
              идентичен тому, что принимает «Импорт JSON».
            </Text>

            <Card padding="md" bordered>
              <Text variant="caption" color="tertiary" style={{ marginBottom: 4 }}>
                СТАТИСТИКА
              </Text>
              <Text variant="small">
                Конструкций: {constructions.length}, фраз всего: {totalPhrases}.
              </Text>
            </Card>

            <Button
              label={copied ? "Скопировано" : "Скопировать в буфер"}
              variant="primary"
              onPress={handleCopy}
              leftIcon={
                copied ? (
                  <Check color={theme.colors.onAccent} size={18} strokeWidth={2.4} />
                ) : (
                  <Copy color={theme.colors.onAccent} size={18} strokeWidth={2.4} />
                )
              }
              fullWidth
            />

            <Card padding="md" bordered>
              <Text
                selectable
                style={{
                  fontFamily: theme.fonts.latin,
                  fontSize: 12,
                  lineHeight: 18,
                  color: theme.colors.textSecondary,
                }}
                chinese
              >
                {json}
              </Text>
            </Card>

            <Text variant="caption" color="tertiary" style={{ marginTop: theme.spacing.md }}>
              ЧТО ВКЛЮЧЕНО
            </Text>
            <Text variant="small" color="secondary">
              Имя конструкции, описание, шаблон и все фразы с переводами на
              языках, которые встречаются в колоде. Внутренние идентификаторы
              и timestamps не экспортируются — они генерируются заново при
              импорте, поэтому два устройства с одинаковыми конструкциями не
              будут конфликтовать.
            </Text>
          </>
        )}
      </ScrollView>
    </Screen>
  );
}
