import { router } from "expo-router";
import {
  ArrowLeft,
  ChevronRight,
  Download,
  Layers,
  Plus,
  Trash2,
  Upload,
} from "lucide-react-native";
import { useState } from "react";
import { Pressable, ScrollView, View } from "react-native";

import { Button, Card, Screen, Text } from "@/components/ui";
import { useHydratedPersonalDeck } from "@/features/grammar/personal";
import { useTheme } from "@/theme";

export default function PersonalIndex() {
  const theme = useTheme();
  const { hydrated, constructions, removeConstruction } = useHydratedPersonalDeck();
  const [confirmingId, setConfirmingId] = useState<string | null>(null);

  const totalPhrases = constructions.reduce((s, c) => s + c.patterns.length, 0);

  return (
    <Screen padded>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: theme.spacing.md,
          paddingTop: theme.spacing.sm,
          paddingBottom: theme.spacing.md,
        }}
      >
        <Pressable onPress={() => router.back()} hitSlop={16} accessibilityLabel="Назад">
          <ArrowLeft color={theme.colors.textSecondary} size={24} strokeWidth={2} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text variant="caption" color="tertiary">
            ЛИЧНАЯ КОЛОДА
          </Text>
          <Text variant="h3">Мои паттерны</Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingBottom: theme.spacing["3xl"],
          gap: theme.spacing.lg,
        }}
      >
        {hydrated && constructions.length === 0 ? (
          <View
            style={{
              padding: theme.spacing.xl,
              borderRadius: theme.radii.lg,
              backgroundColor: theme.colors.surface,
              borderWidth: 1,
              borderColor: theme.colors.border,
              gap: theme.spacing.sm,
            }}
          >
            <Text variant="bodyStrong">Колода пуста</Text>
            <Text variant="small" color="secondary">
              Создайте свою первую конструкцию или импортируйте JSON. Каждая
              конструкция — это одна грамматическая структура и её фразы.
              Принцип спринта: одно явление, разная лексика, рост скорости
              до автоматизма.
            </Text>
          </View>
        ) : (
          <Text variant="small" color="secondary">
            {constructions.length}{" "}
            {pluralize(constructions.length, ["конструкция", "конструкции", "конструкций"])}
            {"  ·  "}
            {totalPhrases} {pluralize(totalPhrases, ["фраза", "фразы", "фраз"])}
          </Text>
        )}

        <View style={{ flexDirection: "row", gap: theme.spacing.sm }}>
          <Button
            label="Создать"
            variant="primary"
            onPress={() => router.push("/(app)/grammar/personal/new")}
            leftIcon={<Plus color={theme.colors.onAccent} size={18} strokeWidth={2.4} />}
            fullWidth
            style={{ flex: 1 }}
          />
          <Button
            label="Импорт JSON"
            variant="secondary"
            onPress={() => router.push("/(app)/grammar/personal/import")}
            leftIcon={<Download color={theme.colors.textPrimary} size={18} strokeWidth={2} />}
            fullWidth
            style={{ flex: 1 }}
          />
        </View>
        {constructions.length > 0 ? (
          <Button
            label="Экспорт JSON"
            variant="ghost"
            onPress={() => router.push("/(app)/grammar/personal/export")}
            leftIcon={<Upload color={theme.colors.accent} size={18} strokeWidth={2} />}
            fullWidth
          />
        ) : null}

        <View style={{ gap: theme.spacing.sm }}>
          {constructions.map((c) => (
            <Card
              key={c.id}
              onPress={() => router.push(`/(app)/grammar/personal/${c.id}`)}
              bordered
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: theme.spacing.lg,
                }}
              >
                <View
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 26,
                    backgroundColor: theme.colors.accentMuted,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text
                    chinese
                    style={{
                      fontSize: 22,
                      lineHeight: 26,
                      fontWeight: "700",
                      color: theme.colors.accent,
                    }}
                    numberOfLines={1}
                  >
                    {firstHanzi(c.name) || "✎"}
                  </Text>
                </View>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text chinese variant="bodyStrong" numberOfLines={1}>
                    {c.name}
                  </Text>
                  {c.ru_name ? (
                    <Text variant="small" color="secondary" numberOfLines={2}>
                      {c.ru_name}
                    </Text>
                  ) : null}
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 6,
                      marginTop: 2,
                    }}
                  >
                    <Layers color={theme.colors.textTertiary} size={14} strokeWidth={2} />
                    <Text variant="caption" color="tertiary">
                      {c.patterns.length}{" "}
                      {pluralize(c.patterns.length, ["фраза", "фразы", "фраз"])}
                      {c.pattern ? `  ·  ${c.pattern}` : ""}
                    </Text>
                  </View>
                </View>
                <Pressable
                  onPress={() => {
                    if (confirmingId === c.id) {
                      removeConstruction(c.id);
                      setConfirmingId(null);
                    } else {
                      setConfirmingId(c.id);
                      // Auto-cancel the danger state after 3s — single-tap delete
                      // is too aggressive but a long flow with Alert.alert breaks
                      // on web/sim previews, so a two-tap-with-timeout is the
                      // pragmatic middle ground.
                      setTimeout(() => setConfirmingId((cur) => (cur === c.id ? null : cur)), 3000);
                    }
                  }}
                  hitSlop={12}
                  accessibilityLabel={
                    confirmingId === c.id
                      ? "Подтвердить удаление"
                      : "Удалить конструкцию"
                  }
                  style={{ padding: 8 }}
                >
                  <Trash2
                    color={confirmingId === c.id ? theme.colors.danger : theme.colors.textTertiary}
                    size={18}
                    strokeWidth={2}
                  />
                </Pressable>
                <ChevronRight color={theme.colors.textTertiary} size={20} strokeWidth={2} />
              </View>
            </Card>
          ))}
        </View>

        <Text variant="caption" color="tertiary" style={{ marginTop: theme.spacing.md }}>
          СОВЕТ
        </Text>
        <Text variant="small" color="secondary">
          Создавайте конструкции под свои слабые места: например «начал делать
          (V起来)» с 30 разными глаголами. Тренируйтесь по тому же сценарию,
          что встроенные HSK-паттерны — таймер + повторы.
        </Text>
      </ScrollView>
    </Screen>
  );
}

function firstHanzi(name: string): string {
  const match = name.match(/^[一-鿿/.]+/);
  return match ? match[0] : "";
}

function pluralize(n: number, forms: [string, string, string]): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return forms[0];
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return forms[1];
  return forms[2];
}
