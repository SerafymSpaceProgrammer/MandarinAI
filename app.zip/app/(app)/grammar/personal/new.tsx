import { router } from "expo-router";
import { ArrowLeft } from "lucide-react-native";
import { useState } from "react";
import { Pressable, ScrollView, View } from "react-native";

import { Button, Input, Screen, Text, useToast } from "@/components/ui";
import { useHydratedPersonalDeck } from "@/features/grammar/personal";
import { useTheme } from "@/theme";

export default function NewPersonalConstruction() {
  const theme = useTheme();
  const toast = useToast();
  const { createConstruction } = useHydratedPersonalDeck();

  const [name, setName] = useState("");
  const [ruName, setRuName] = useState("");
  const [pattern, setPattern] = useState("");

  const canSave = name.trim().length > 0;

  const handleSave = () => {
    if (!canSave) return;
    const id = createConstruction({ name, ru_name: ruName, pattern });
    toast.success("Конструкция создана");
    router.replace(`/(app)/grammar/personal/${id}`);
  };

  return (
    <Screen padded>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: theme.spacing.md,
          paddingTop: theme.spacing.sm,
          paddingBottom: theme.spacing.md,
        }}
      >
        <Pressable onPress={() => router.back()} hitSlop={16} accessibilityLabel="Назад">
          <ArrowLeft color={theme.colors.textSecondary} size={24} strokeWidth={2} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text variant="caption" color="tertiary">
            ЛИЧНАЯ КОЛОДА
          </Text>
          <Text variant="h3">Новая конструкция</Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingBottom: theme.spacing["3xl"],
          gap: theme.spacing.lg,
        }}
        keyboardShouldPersistTaps="handled"
      >
        <Text variant="small" color="secondary">
          Опишите грамматическую структуру, которую хотите отрабатывать. Фразы
          добавите на следующем шаге.
        </Text>

        <Input
          label="Название (китайский + пиньинь)"
          placeholder="例: 把 bǎ"
          chinese
          value={name}
          onChangeText={setName}
          helper="Главный иероглиф и его чтение"
        />

        <Input
          label="Описание (на вашем языке)"
          placeholder="例: Конструкция вынесения объекта"
          value={ruName}
          onChangeText={setRuName}
        />

        <Input
          label="Структура / шаблон"
          placeholder="例: S + 把 + O + V + 了"
          value={pattern}
          onChangeText={setPattern}
          chinese
          helper="Используйте символы S/O/V/adj и иероглифы конструкции"
        />

        <View style={{ height: theme.spacing.md }} />

        <Button
          label="Создать конструкцию"
          variant="primary"
          onPress={handleSave}
          disabled={!canSave}
          fullWidth
        />
      </ScrollView>
    </Screen>
  );
}
