import * as Haptics from "expo-haptics";
import * as Speech from "expo-speech";
import { router, useLocalSearchParams } from "expo-router";
import { ArrowRight, Mic, Square, Volume2, X } from "lucide-react-native";
import { useEffect, useRef, useState } from "react";
import { Animated, Easing, Pressable, ScrollView, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Screen, Text, useToast } from "@/components/ui";
import { useT } from "@/i18n/i18n";
import { fmt } from "@/i18n/strings";
import { recordActivity } from "@/features/activity/activity";
import { recordLastSpeakingAttempt } from "@/features/practice/usePracticeData";
import { findScenario, type Scenario, type ScenarioTurn } from "@/features/speaking/scenarios";
import { scorePronunciation, type PronunciationResult } from "@/features/speaking/score";
import { cancelActiveRecording, ensureMicPermission, startRecording } from "@/features/speaking/recorder";
import { useUserStore } from "@/stores/userStore";
import { useTheme } from "@/theme";

type TurnOutcome = {
  turnIdx: number;
  score: number;
  transcript: string;
};

type PhaseState =
  | { kind: "idle" }
  | { kind: "recording"; stopFn: () => Promise<{ uri: string; mimeType: string } | null> }
  | { kind: "scoring" }
  | { kind: "revealed"; result: PronunciationResult };

export default function ScenarioSession() {
  const theme = useTheme();
  const t = useT();
  const toast = useToast();
  const insets = useSafeAreaInsets();
  const session = useUserStore((s) => s.session);
  const params = useLocalSearchParams<{ id?: string }>();
  const scenario = params.id ? findScenario(params.id) : undefined;

  const [turnIdx, setTurnIdx] = useState(0);
  const [phase, setPhase] = useState<PhaseState>({ kind: "idle" });
  const [outcomes, setOutcomes] = useState<TurnOutcome[]>([]);
  const [startedAt] = useState(() => Date.now());

  const current: ScenarioTurn | undefined = scenario?.turns[turnIdx];

  // Auto-play NPC turns on mount, then auto-advance after a short hold.
  useEffect(() => {
    if (!current) return;
    if (current.speaker !== "npc") return;
    Speech.stop().catch(() => {});
    const id = setTimeout(() => {
      Speech.speak(current.hanzi, { language: "zh-CN", rate: 0.9 });
    }, 250);
    return () => {
      clearTimeout(id);
      Speech.stop().catch(() => {});
    };
  }, [current]);

  // Pulse animation on the mic while recording.
  const pulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (phase.kind !== "recording") {
      pulse.setValue(1);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.15, duration: 600, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 600, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [phase.kind, pulse]);

  // Only show the "not found" screen when the scenario itself is missing
  // (bad/unknown id). `current` becomes undefined naturally when the user
  // finishes the last turn (turnIdx === turns.length) — at that point the
  // `finished` branch below renders the summary, which is the correct end
  // state. The previous combined check sent the user straight to the
  // "not found" page after every completed session.
  if (!scenario) {
    return (
      <Screen padded>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: theme.spacing.md }}>
          <Text variant="h2" align="center">{t.speaking.sessionNotFound}</Text>
          <Button
            label={t.common.back}
            variant="secondary"
            onPress={() => router.replace("/(app)/practice/scenarios")}
          />
        </View>
      </Screen>
    );
  }

  const progress = (turnIdx + 1) / scenario.turns.length;

  async function playNpcAgain() {
    if (!current || current.speaker !== "npc") return;
    Speech.stop().catch(() => {});
    Speech.speak(current.hanzi, { language: "zh-CN", rate: 0.9 });
  }

  async function startRecord() {
    const granted = await ensureMicPermission();
    if (!granted) {
      toast.error(t.speaking.micPermission);
      return;
    }
    try {
      const handle = await startRecording();
      setPhase({ kind: "recording", stopFn: handle.stop });
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    } catch (err) {
      toast.error(t.speaking.recordingError);
      console.warn(err);
    }
  }

  async function stopAndScore() {
    if (phase.kind !== "recording") return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setPhase({ kind: "scoring" });
    const file = await phase.stopFn();
    if (!file || !current || current.speaker !== "you") {
      setPhase({ kind: "idle" });
      return;
    }

    const res = await scorePronunciation(
      file.uri,
      file.mimeType,
      current.hanzi,
      current.pinyin,
    );
    if (!res.ok) {
      setPhase({ kind: "idle" });
      const err = res.error;
      switch (err.kind) {
        case "audio_too_short":
          toast.info(t.speaking.audioTooShort);
          return;
        case "daily_limit":
          toast.info(fmt(t.speaking.dailyLimit, { used: err.used, limit: err.limit }));
          return;
        case "network":
          toast.error(t.speaking.networkError);
          return;
        default:
          toast.error(fmt(t.speaking.genericError, { kind: err.kind }));
          return;
      }
    }

    setPhase({ kind: "revealed", result: res.result });
    if (session) {
      recordActivity(session.user.id, {
        exercises_completed: 1,
        xp_earned: res.result.score >= 60 ? 3 : 1,
      });
    }
  }

  function nextTurn() {
    if (!scenario) return;
    if (phase.kind === "revealed" && current?.speaker === "you") {
      setOutcomes((prev) => [
        ...prev,
        {
          turnIdx,
          score: phase.result.score,
          transcript: phase.result.transcript,
        },
      ]);
    }
    const nextIdx = turnIdx + 1;
    if (nextIdx >= scenario.turns.length) {
      // Session over — record minutes and show summary inline.
      if (session) {
        const minutes = Math.max(1, Math.round((Date.now() - startedAt) / 60_000));
        recordActivity(session.user.id, { minutes_studied: minutes, conversations_completed: 1 });
      }
      // Stash a snapshot of the best-scoring turn so the Practice tab can
      // surface it as a "Last attempt" hero. Picking the best (not the most
      // recent) makes the card feel rewarding rather than dunk-on-your-flubs.
      const allOutcomes =
        phase.kind === "revealed" && current?.speaker === "you"
          ? [
              ...outcomes,
              {
                turnIdx,
                score: phase.result.score,
                transcript: phase.result.transcript,
              },
            ]
          : outcomes;
      if (allOutcomes.length > 0) {
        const best = allOutcomes.reduce((a, b) => (a.score >= b.score ? a : b));
        const bestTurn = scenario.turns[best.turnIdx];
        if (bestTurn) {
          const avg = Math.round(
            allOutcomes.reduce((s, o) => s + o.score, 0) / allOutcomes.length,
          );
          void recordLastSpeakingAttempt({
            scenarioId: scenario.id,
            scenarioTitle: scenario.title,
            hskLevel: scenario.hskLevel,
            hanzi: bestTurn.hanzi,
            pinyin: bestTurn.pinyin,
            score: avg,
            timestamp: Date.now(),
          });
        }
      }
      setTurnIdx(nextIdx);
      setPhase({ kind: "idle" });
      return;
    }
    setTurnIdx(nextIdx);
    setPhase({ kind: "idle" });
  }

  async function quit() {
    await cancelActiveRecording();
    router.back();
  }

  const finished = turnIdx >= scenario.turns.length;

  // ────────────────────────── SUMMARY ──────────────────────────
  if (finished) {
    return (
      <SessionSummary
        scenario={scenario}
        outcomes={outcomes}
        onReplay={() => {
          // Re-arm in place — restart at turn 0 with a fresh outcome list.
          setOutcomes([]);
          setPhase({ kind: "idle" });
          setTurnIdx(0);
        }}
      />
    );
  }

  // After `finished` is handled, turnIdx < scenario.turns.length so
  // `current` is guaranteed to exist. The narrowing helper makes TS see
  // that — otherwise it can't infer the relationship between `finished`
  // and the optional `current` lookup.
  if (!current) return null;

  // ────────────────────────── IN-SESSION ──────────────────────────
  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.bg }}>
      {/* Header + progress */}
      <View
        style={{
          paddingTop: insets.top + theme.spacing.sm,
          paddingHorizontal: theme.spacing.lg,
          paddingBottom: theme.spacing.md,
          gap: theme.spacing.sm,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Pressable onPress={quit} hitSlop={16} accessibilityLabel={t.common.close}>
            <X color={theme.colors.textSecondary} size={24} strokeWidth={2} />
          </Pressable>
          <Text variant="small" color="tertiary">
            {fmt(t.vocab.review.counter, { n: turnIdx + 1, total: scenario.turns.length })}
          </Text>
          <View style={{ width: 24 }} />
        </View>
        <View
          style={{
            height: 4,
            backgroundColor: theme.colors.surface,
            borderRadius: 2,
            overflow: "hidden",
          }}
        >
          <View
            style={{
              width: `${progress * 100}%`,
              height: "100%",
              backgroundColor: theme.colors.accent,
            }}
          />
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{
          padding: theme.spacing.lg,
          gap: theme.spacing.xl,
          paddingBottom: 120,
        }}
      >
        {/* Setting card, only on first turn */}
        {turnIdx === 0 ? (
          <View
            style={{
              padding: theme.spacing.md,
              borderRadius: theme.radii.md,
              backgroundColor: theme.colors.surface,
              borderWidth: 1,
              borderColor: theme.colors.border,
              gap: 2,
            }}
          >
            <Text variant="caption" color="tertiary">
              {t.speaking.setting}
            </Text>
            <Text variant="small">{scenario.setting}</Text>
          </View>
        ) : null}

        {/* Current turn card */}
        <View
          style={{
            padding: theme.spacing.lg,
            borderRadius: theme.radii.lg,
            borderWidth: 1,
            borderColor: current.speaker === "you" ? theme.colors.accent : theme.colors.border,
            backgroundColor: current.speaker === "you" ? theme.colors.accentMuted : theme.colors.surface,
            gap: theme.spacing.sm,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <Text variant="caption" color={current.speaker === "you" ? "accent" : "tertiary"}>
              {current.speaker === "you" ? t.speaking.yourLine : t.speaking.theySay}
            </Text>
            {current.speaker === "npc" ? (
              <Pressable onPress={playNpcAgain} hitSlop={12} accessibilityLabel={t.vocab.review.tapToReplay}>
                <Volume2 color={theme.colors.textSecondary} size={20} strokeWidth={2} />
              </Pressable>
            ) : null}
          </View>
          <Text chinese variant="h1">
            {current.hanzi}
          </Text>
          <Text variant="pinyin" color="secondary">
            {current.pinyin}
          </Text>
          <Text variant="body" color="secondary">
            {current.english}
          </Text>
        </View>

        {/* Scoring feedback */}
        {phase.kind === "revealed" ? (
          <FeedbackCard expected={current.hanzi} result={phase.result} />
        ) : null}

      </ScrollView>

      {/* Bottom action area */}
      <View
        style={{
          padding: theme.spacing.lg,
          paddingBottom: Math.max(insets.bottom, theme.spacing.lg),
          gap: theme.spacing.md,
          borderTopWidth: 1,
          borderTopColor: theme.colors.border,
          backgroundColor: theme.colors.bg,
        }}
      >
        {current.speaker === "npc" ? (
          <Button
            label={t.common.continue}
            size="lg"
            fullWidth
            rightIcon={<ArrowRight color={theme.colors.onAccent} size={18} strokeWidth={2.4} />}
            onPress={nextTurn}
          />
        ) : phase.kind === "revealed" ? (
          <Button
            label={t.speaking.nextLine}
            size="lg"
            fullWidth
            rightIcon={<ArrowRight color={theme.colors.onAccent} size={18} strokeWidth={2.4} />}
            onPress={nextTurn}
          />
        ) : (
          <View style={{ alignItems: "center", gap: theme.spacing.sm }}>
            <Animated.View style={{ transform: [{ scale: pulse }] }}>
              <Pressable
                onPress={phase.kind === "recording" ? stopAndScore : startRecord}
                disabled={phase.kind === "scoring"}
                accessibilityLabel={phase.kind === "recording" ? t.speaking.tapToStop : t.speaking.tapAndSay}
                style={{
                  width: 84,
                  height: 84,
                  borderRadius: 42,
                  backgroundColor:
                    phase.kind === "recording" ? theme.colors.danger : theme.colors.accent,
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: phase.kind === "scoring" ? 0.5 : 1,
                }}
              >
                {phase.kind === "recording" ? (
                  <Square color={theme.colors.onAccent} size={30} strokeWidth={2} fill={theme.colors.onAccent} />
                ) : (
                  <Mic color={theme.colors.onAccent} size={36} strokeWidth={2.2} />
                )}
              </Pressable>
            </Animated.View>
            <Text variant="small" color="tertiary">
              {phase.kind === "recording"
                ? t.speaking.tapToStop
                : phase.kind === "scoring"
                  ? t.speaking.scoring
                  : t.speaking.tapAndSay}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}

// ────────────────────────── FEEDBACK CARD ──────────────────────────
function FeedbackCard({ expected, result }: { expected: string; result: PronunciationResult }) {
  const theme = useTheme();
  const t = useT();

  const verdictColor: "success" | "warning" | "danger" =
    result.verdict === "excellent" || result.verdict === "good"
      ? "success"
      : result.verdict === "try_again"
        ? "warning"
        : "danger";

  const verdictLabel: Record<PronunciationResult["verdict"], string> = {
    excellent: t.speaking.verdictExcellent,
    good: t.speaking.verdictGood,
    try_again: t.speaking.verdictTryAgain,
    unclear: t.speaking.verdictUnclear,
  };

  return (
    <View
      style={{
        padding: theme.spacing.lg,
        borderRadius: theme.radii.md,
        backgroundColor: theme.colors.surface,
        borderWidth: 1,
        borderColor: theme.colors[verdictColor],
        gap: theme.spacing.md,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <Text variant="bodyStrong" color={verdictColor}>
          {verdictLabel[result.verdict]}
        </Text>
        <Text variant="h2" color={verdictColor}>
          {result.score}%
        </Text>
      </View>

      <View style={{ gap: 4 }}>
        <Text variant="caption" color="tertiary">
          {t.speaking.expectedHeard}
        </Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
          {result.perChar.map((p, i) => (
            <Text
              key={i}
              chinese
              style={{
                fontSize: 24,
                color: p.matched ? theme.colors.success : theme.colors.danger,
                fontWeight: "700",
              }}
            >
              {p.char}
            </Text>
          ))}
        </View>
        {result.transcript ? (
          <Text variant="small" color="secondary">
            {fmt(t.speaking.heardLabel, { transcript: result.transcript })}
          </Text>
        ) : null}
      </View>

      {result.toneAnalysis ? (
        <View style={{ gap: 4 }}>
          <Text variant="caption" color="tertiary">
            {t.speaking.tonesLabel}
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {result.toneAnalysis.perSyllable.map((s, i) => (
              <View
                key={i}
                style={{
                  paddingHorizontal: 6,
                  paddingVertical: 3,
                  borderRadius: 6,
                  backgroundColor: s.correct ? "#DCEEDB" : "#FCE4E6",
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <Text
                  chinese
                  style={{
                    fontSize: 16,
                    fontWeight: "700",
                    color: s.correct ? "#1F8A5B" : "#B5101F",
                  }}
                >
                  {s.hanzi}
                </Text>
                <Text
                  style={{
                    fontSize: 11,
                    fontWeight: "700",
                    color: s.correct ? "#1F8A5B" : "#B5101F",
                  }}
                >
                  {s.heard_tone}/{s.expected_tone}
                </Text>
              </View>
            ))}
          </View>
          {result.toneAnalysis.notes ? (
            <Text variant="small" color="secondary" style={{ marginTop: 2 }}>
              {result.toneAnalysis.notes}
            </Text>
          ) : null}
        </View>
      ) : null}

      <Text variant="caption" color="tertiary">
        {fmt(t.speaking.targetLabel, { expected })}
      </Text>
    </View>
  );
}

// ────────────────────────── SUMMARY ──────────────────────────
function SessionSummary({
  scenario,
  outcomes,
  onReplay,
}: {
  scenario: Scenario;
  outcomes: TurnOutcome[];
  onReplay: () => void;
}) {
  const theme = useTheme();
  const t = useT();

  const avg = outcomes.length
    ? Math.round(outcomes.reduce((s, o) => s + o.score, 0) / outcomes.length)
    : 0;
  const youTurns = scenario.turns.filter((turn) => turn.speaker === "you").length;
  const xp = outcomes.reduce((s, o) => s + (o.score >= 60 ? 3 : 1), 0);

  return (
    <Screen padded>
      <ScrollView
        contentContainerStyle={{
          paddingTop: theme.spacing.lg,
          paddingBottom: theme.spacing["3xl"],
          gap: theme.spacing.xl,
        }}
      >
        <View style={{ alignItems: "center", gap: theme.spacing.md }}>
          <Text style={{ fontSize: 72, lineHeight: 80 }}>{scenario.emoji}</Text>
          <Text variant="h1" align="center">
            {fmt(t.speaking.summaryTitle, { title: scenario.title })}
          </Text>
          <Text variant="body" color="secondary" align="center">
            {fmt(t.speaking.summarySubtitle, {
              scored: outcomes.length,
              total: youTurns,
              avg,
              xp,
            })}
          </Text>
        </View>

        <View
          style={{
            padding: theme.spacing.lg,
            borderRadius: theme.radii.md,
            backgroundColor: theme.colors.surface,
            borderWidth: 1,
            borderColor: theme.colors.border,
            gap: theme.spacing.md,
          }}
        >
          <Text variant="caption" color="tertiary">
            {t.speaking.transcriptHeader}
          </Text>
          {scenario.turns.map((turn, i) => {
            const outcome = outcomes.find((o) => o.turnIdx === i);
            const scoreColor: "success" | "warning" | "danger" | "tertiary" = outcome
              ? outcome.score >= 80
                ? "success"
                : outcome.score >= 50
                  ? "warning"
                  : "danger"
              : "tertiary";

            return (
              <View key={i} style={{ gap: 2 }}>
                <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                  <Text variant="caption" color={turn.speaker === "you" ? "accent" : "tertiary"}>
                    {turn.speaker === "you" ? t.speaking.youLabel : t.speaking.npcLabel}
                  </Text>
                  {outcome ? (
                    <Text variant="smallStrong" color={scoreColor}>
                      {outcome.score}%
                    </Text>
                  ) : null}
                </View>
                <Text chinese variant="bodyStrong">
                  {turn.hanzi}
                </Text>
                <Text variant="small" color="secondary">
                  {turn.english}
                </Text>
              </View>
            );
          })}
        </View>

        <View style={{ gap: theme.spacing.sm }}>
          <Button
            label={t.speaking.practiceAgain}
            size="lg"
            fullWidth
            // Reset state via the parent's callback instead of replacing
            // the route — same URL replace doesn't re-mount the component,
            // so turnIdx would stay past the end and the screen would
            // bounce to "Session not found".
            onPress={onReplay}
          />
          <Button
            label={t.speaking.pickAnother}
            variant="secondary"
            fullWidth
            onPress={() => router.replace("/(app)/practice/scenarios")}
          />
          <Button label={t.common.done} variant="ghost" fullWidth onPress={() => router.replace("/(app)")} />
        </View>
      </ScrollView>
    </Screen>
  );
}
