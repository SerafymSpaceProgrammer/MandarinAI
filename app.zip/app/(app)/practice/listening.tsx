import { router } from "expo-router";
import { ArrowLeft, Headphones, Play } from "lucide-react-native";
import { useState } from "react";
import { Pressable, ScrollView, View } from "react-native";

import { Button, Card, Screen, Text } from "@/components/ui";
import {
  ALL_LEXICAL_LEVELS,
  type LexicalLevel,
} from "@/features/grammar/patterns";
import { useTheme } from "@/theme";

export default function ListeningPicker() {
  const theme = useTheme();
  const [level, setLevel] = useState<LexicalLevel>(1);

  return (
    <Screen padded>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: theme.spacing.md,
          paddingTop: theme.spacing.sm,
          paddingBottom: theme.spacing.md,
        }}
      >
        <Pressable onPress={() => router.back()} hitSlop={16} accessibilityLabel="Назад">
          <ArrowLeft color={theme.colors.textSecondary} size={24} strokeWidth={2} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text variant="caption" color="tertiary">
            ПРАКТИКА · СЛУШАНИЕ
          </Text>
          <Text variant="h3">Listening Drills</Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingBottom: theme.spacing["3xl"],
          gap: theme.spacing.lg,
        }}
      >
        <Card padding="lg" bordered>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: theme.spacing.md,
              marginBottom: theme.spacing.md,
            }}
          >
            <View
              style={{
                width: 52,
                height: 52,
                borderRadius: 26,
                backgroundColor: theme.colors.accentMuted,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Headphones color={theme.colors.accent} size={26} strokeWidth={2} />
            </View>
            <View style={{ flex: 1 }}>
              <Text variant="bodyStrong">10 фраз на слух</Text>
              <Text variant="small" color="secondary">
                Слушаете → выбираете перевод → проверяете себя
              </Text>
            </View>
          </View>
          <Text variant="small" color="secondary">
            Включается голос Mandarin (zh-CN), вы выбираете правильный перевод
            из четырёх вариантов на вашем языке. После ответа — иероглифы,
            пиньинь и возможность повторить.
          </Text>
        </Card>

        <View style={{ gap: theme.spacing.sm }}>
          <Text variant="caption" color="tertiary">
            УРОВЕНЬ ЛЕКСИКИ
          </Text>
          <Text variant="small" color="secondary">
            Чем выше — тем шире пул фраз. HSK 1 — только базовая лексика;
            HSK 1–6 — все слова до продвинутого.
          </Text>
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              gap: theme.spacing.sm,
              marginTop: theme.spacing.xs,
            }}
          >
            {ALL_LEXICAL_LEVELS.map((lvl) => (
              <LevelChip
                key={lvl}
                level={lvl}
                active={lvl === level}
                onPress={() => setLevel(lvl)}
              />
            ))}
          </View>
        </View>

        <Button
          label="Начать"
          variant="primary"
          onPress={() =>
            router.push(`/(app)/practice/listening-session?level=${level}`)
          }
          leftIcon={<Play color={theme.colors.onAccent} size={18} strokeWidth={2.4} />}
          fullWidth
        />

        <Text variant="caption" color="tertiary" style={{ marginTop: theme.spacing.md }}>
          СОВЕТ
        </Text>
        <Text variant="small" color="secondary">
          Сначала прослушайте без подсказок. Если не уловили — перезапустите
          аудио (доступно до 3 раз). Не переключайтесь сразу на текст —
          натренируйте ухо различать слова в потоке.
        </Text>
      </ScrollView>
    </Screen>
  );
}

function LevelChip({
  level,
  active,
  onPress,
}: {
  level: LexicalLevel;
  active: boolean;
  onPress: () => void;
}) {
  const theme = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      style={{
        paddingHorizontal: theme.spacing.lg,
        paddingVertical: 10,
        borderRadius: theme.radii.full,
        backgroundColor: active ? theme.colors.accent : theme.colors.surface,
        borderWidth: 1,
        borderColor: active ? theme.colors.accent : theme.colors.border,
      }}
    >
      <Text variant="bodyStrong" color={active ? "onAccent" : "primary"}>
        HSK {level === 1 ? 1 : `1–${level}`}
      </Text>
    </Pressable>
  );
}
