import { Stack } from "expo-router";

export default function VocabLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: "transparent" },
        animation: "slide_from_right",
        animationDuration: 180,
      }}
    />
  );
}
